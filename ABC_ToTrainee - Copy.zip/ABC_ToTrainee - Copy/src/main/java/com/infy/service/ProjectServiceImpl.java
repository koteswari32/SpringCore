package com.infy.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.ProjectDAO;
import com.infy.model.Project;
import com.infy.model.TeamMember;
import com.infy.validator.Validator;

@Service("projectService")
public class ProjectServiceImpl implements ProjectService {
	
	@Autowired
	private ProjectDAO dao;
	

	@Override
	public Integer addProject(Project project) {
			
		List<TeamMember> memberList=project.getMemberList();
		Integer p=0;
		for(TeamMember tm:memberList) {
			Integer employeeId=tm.getEmployeeId();
			try {
			 Validator.validateEmployeeId(employeeId);
				dao.addProject(project);
			    p=dao.addProject(project);
				
			}
			catch(Exception e) {
				System.out.println(e);
			}
			 
		
		}
		 return p;
		
	  
	
	}

	
	@Override
	public List<Project> getProjectDetails(String technology) throws Exception {
		
		List<Project> plist=new ArrayList<>();
		List<Project> list=dao.getProjectDetails();
		for(Project p:list) {
			if(p.getTechnologyUsed().equals(technology)) {
				plist.add(p);
			}
		}
		if(plist.isEmpty()) {
				throw new Exception("Service.PROJECTS_NOT_FOUND");
		}
		
		
		return plist;
	}


	
}
