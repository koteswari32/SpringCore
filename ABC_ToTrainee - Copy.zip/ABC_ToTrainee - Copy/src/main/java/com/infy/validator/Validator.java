package com.infy.validator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import com.infy.model.TeamMember;

@Component
public class Validator {
	
	//private static final Log LOGGER=LogFactory.getLog(Validator.class);

	public static void validate(TeamMember teamMember) throws Exception {
		
		if(validateEmployeeId(teamMember.getEmployeeId())==false) {
			throw new Exception("Validator.INVALID_EMPLOYEEID");
		}
       
	}

	public static Boolean validateEmployeeId(Integer employeeId) throws Exception {
		
		String regex="^[0-9]{6}$";
		if(employeeId.toString().matches(regex)) {
			return true;
		}
		return false;
	}

}
