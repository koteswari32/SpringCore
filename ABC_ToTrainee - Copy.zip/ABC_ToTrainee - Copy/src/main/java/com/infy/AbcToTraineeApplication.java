package com.infy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.infy.model.Project;
import com.infy.model.TeamMember;
import com.infy.service.ProjectService;


@SpringBootApplication
public class AbcToTraineeApplication implements CommandLineRunner {

	@Autowired
	
	private Environment env;
	
	@Autowired
	private ProjectService projectService;
	
	public static void main(String[] args) {
		SpringApplication.run(AbcToTraineeApplication.class, args);
		
		
	}

	@Override
	public void run(String... args) throws Exception {

		addProject();
		//getProjectDetails();
		//System.out.println(env.getProperty("General.EXCEPTION"));
		//System.out.println(env.getProperty("UserInterface.PROJECT_ADDED_SUCCESS"));
	}

	public void addProject() throws Exception{
		
		TeamMember t1=new TeamMember();
		t1.setEmployeeId(722009);
		t1.setEmployeeName("Tom");
		t1.setDesignation("SSC");
		t1.setSkills("Java");
		
		TeamMember t2=new TeamMember();
		t2.setEmployeeId(7220);
		t2.setEmployeeName("Koteswari");
		t2.setDesignation("SSC");
		t2.setSkills("Oracle");
		
		List<TeamMember> team=new ArrayList<>();
		team.add(t1);
		team.add(t2);
		
		
		Project project=new Project();
		project.setProjectName("FSADM8");
		project.setCost(200000);
		project.setTeamSize(5);
		project.setTechnologyUsed("Java");
		project.setMemberList(team);
		
		Integer p=projectService.addProject(project);
		System.out.println(env.getProperty("UserInterface.PROJECT_ADDED_SUCCESS")+ project.getProjectId());
		

	}

	public void getProjectDetails() throws Exception{
		
		  List<Project> projectDetails=projectService.getProjectDetails("Ja");
		  if(projectDetails.isEmpty()) {
		      System.out.println(env.getProperty("Service.PROJECTS_NOT_FOUND"));
		  }
		  else {
			  System.out.println(projectDetails);
		  }
     
	}

}
