package com.infy.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.infy.repository.InsuranceRepository;
import com.infy.repository.InsuranceRepositoryImpl;
import com.infy.service.InsuranceService;
import com.infy.service.InsuranceServiceImpl;

@Configuration
@ComponentScan(basePackages="com.infy")
public class SpringConfig {
//	@Bean
//	public InsuranceRepository insuranceRepository() {
//		return new InsuranceRepositoryImpl();
//	}
	
	@Bean
	public InsuranceService insuranceService() {
		return new InsuranceServiceImpl();
	}
	
	
	
	

}