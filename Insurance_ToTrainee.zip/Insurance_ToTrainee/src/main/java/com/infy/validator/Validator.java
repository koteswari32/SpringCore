package com.infy.validator;

import java.time.LocalDate;

import com.infy.exception.InsuranceException;
import com.infy.model.PolicyDTO;

public class Validator {


	public static void validate(PolicyDTO policy) throws InsuranceException{
		if(validatePolicyName(policy.getPolicyName())==false) {
			throw new InsuranceException("Validator.INVALID_POLICY_NAME");
		}
		if(validatePolicyType(policy.getPolicyType())==false) {
			throw new InsuranceException("Validator.INVALID_POLICY_TYPE");
		}
		if(validatePolicyHolderName(policy.getPolicyHolderName())==false) {
			throw new InsuranceException("Validator.INVALID_HOLDER_NAME");
		}
		if(validatePolicyNumber(policy.getPolicyNumber(), policy.getPolicyType())==false) {
			throw new InsuranceException("Validator.INVALID_POLICY_NUMBER");
		}
		if(validateDateOfBirth(policy.getDateOfBirth())==false) {
			throw new InsuranceException("Validator.INVALID_DOB");
		}
		if(validatePremium(policy.getPremium())==false) {
			throw new InsuranceException("Validator.INVALID_PREMIUM");
		}
		
		if(validateTenure(policy.getTenureInMonths())==false) {
			throw new InsuranceException("Validator.INVALID_TENURE");
		}
		
	}

	
	public static Boolean validatePolicyName(String policyName){
        if(policyName.matches("[A-Za-z]+") && !(policyName.isEmpty())) {
        	return true;
        }
		return false;

	}
	
	public static Boolean validatePolicyType(String policyType){
       if(policyType.matches("Term Life Insurance | Whole Life Policy | Endowment Plans")) {
    	   return true;
       }
		return false;

	}
	
	public static Boolean validatePremium(Double premium){
       if(premium<100) {
    	   return false;
       }
		return true;

	}
	
	public static Boolean validateTenure(Integer tenureInMonths){
        
		if(tenureInMonths<24) {
			return false;
		}
		
		return true;

	}

	
	public static Boolean validateDateOfBirth(LocalDate dateOfBirth){
       if(dateOfBirth.isBefore(LocalDate.now())) {
    	   return true;
       }
		return false;

	}

	
	public static Boolean validatePolicyNumber(String policyNumber,String policyType){
       
		String r1="[TM|WL|EP]";
		String r2="[0-9]{6}";
		if(policyNumber.matches(r2) && policyType.matches(r1)) {
			return true;
		}
		return false;

	}

	
	public static Boolean validatePolicyHolderName(String policyHolderName){
        if(policyHolderName.matches("[A-Za-z]+{3}") || policyHolderName.matches("[A-Za-z]+(\\s[A-Za-z]+)*")) {
        	return true;
        }
		return false;

	}
}
