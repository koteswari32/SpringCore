package com.infy.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.exception.InsuranceException;
import com.infy.model.PolicyDTO;
import com.infy.model.PolicyReportDTO;
import com.infy.repository.InsuranceRepository;
import com.infy.validator.Validator;

@Service
public class InsuranceServiceImpl implements InsuranceService{
	
	@Autowired
	private InsuranceRepository insuranceRepository;


	public String buyPolicy(PolicyDTO policy) throws InsuranceException {
		String s="";
		try {
		   Validator.validate(policy); 
		    s=insuranceRepository.buyPolicy(policy);
		}catch(InsuranceException e) {
			throw e;
			
		}
		 
		return s;
	}

	public Long calculateAge(LocalDate dateOfBirth) throws InsuranceException {
		
		return null;
	}

	public List<PolicyReportDTO> getReport(String policyType) throws InsuranceException {
		
		return null;
	}

		
	
	
}
