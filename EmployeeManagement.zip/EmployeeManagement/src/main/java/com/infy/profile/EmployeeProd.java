package com.infy.profile;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component("EmployeeProd")
@Profile("prod")
public class EmployeeProd {
    private static final Log LOGGER=LogFactory.getLog(EmployeeProd.class);
    
    @Autowired
    Environment env;
    
    public EmployeeProd() {
    	LOGGER.info("Employee bean for production environment");
    }
    
    public void insertEmployee() {
    	LOGGER.info(env.getProperty("message"));
    }
}
