package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.infy.dto.EmployeeDTO;
import com.infy.repository.EmployeeRepository;


@Service("employeeService")
@Scope("prototype")
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public void insert(EmployeeDTO employee) {
		
		employeeRepository.insertEmployee(employee);
	}

	@Override
	public void delete(int empId) {
		
		//uncomment the below line to see the AfterThrowing Advice
		//int i=10/0;
		employeeRepository.removeEmployee(empId);
	}

	@Override
	public List<EmployeeDTO> getAllEmployees() {
		
		return employeeRepository.allEmployee();
	}

}
