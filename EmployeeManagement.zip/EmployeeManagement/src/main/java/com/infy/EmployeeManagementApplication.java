package com.infy;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.AbstractApplicationContext;

import com.infy.profile.EmployeeDev;
import com.infy.profile.EmployeeProd;
import com.infy.service.EmployeeServiceImpl;

@SpringBootApplication
public class EmployeeManagementApplication{

	public static void main(String[] args) {
		
		AbstractApplicationContext context=(AbstractApplicationContext) SpringApplication.run(EmployeeManagementApplication.class, args);
		
		EmployeeServiceImpl employeeService1=(EmployeeServiceImpl) context.getBean("employeeService");
		EmployeeServiceImpl employeeService2=(EmployeeServiceImpl) context.getBean("employeeService");
		
		/*Development Environment*/
		EmployeeDev employeeDev=(EmployeeDev) context.getBean("EmployeeDev");
		employeeDev.insertEmployeeDev();
		
		/*Production Environment*/
// 		EmployeeProd employeeProd=(EmployeeProd) context.getBean("EmployeeProd");
// 		employeeProd.insertEmployee();
		
		

	
		
		//method calling to check the AfterThrowing Advice
		employeeService1.delete(10304);
		
		System.out.println("Hashcode of Employee1: "+employeeService1.hashCode());
		System.out.println("Hashcode of Employee2: "+employeeService2.hashCode());
		
		if(employeeService1==employeeService2) {
			System.out.println("Same instance is created for Employee services - depicting Singleton Scope ");
		}
		else {
			System.out.println("Different instances are created for employee services - depicting Prototype scope");
		}
		

		
		
		
		
	}


}
