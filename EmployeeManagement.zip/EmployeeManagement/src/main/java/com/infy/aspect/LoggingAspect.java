package com.infy.aspect;


import java.text.DateFormat;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {
	
	private static final Logger LOGGER=LoggerFactory.getLogger(LoggingAspect.class);
	
	@AfterThrowing(pointcut="execution(* com.infy.service.EmployeeServiceImpl.*(..))",throwing="exception")
	public void logAfterThrowingAdviceDetails(JoinPoint joinPoint, Exception exception) {
		LOGGER.info("In After throwing Advice, Joinpoint signature :{}",joinPoint.getSignature());
		long time=System.currentTimeMillis();
		String date=DateFormat.getDateTimeInstance().format(time);
		LOGGER.info("Report generated at time:{}", date);
		LOGGER.error(exception.getMessage(),exception);
		
	}
	

}
