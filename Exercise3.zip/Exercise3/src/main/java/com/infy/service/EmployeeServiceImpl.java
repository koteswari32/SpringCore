package com.infy.service;

import java.util.List;

import com.infy.dto.EmployeeDTO;
import com.infy.repository.EmployeeRepository;

public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeRepository employeeRepository;
	
	public EmployeeServiceImpl() {
	}
	
	/*
		Write the code to inject the bean employeeRepository using setter function
	*/
	//Dependency injection by Setter
	public void setRepository(EmployeeRepository employeeRepository) {
		this.employeeRepository=employeeRepository;
	}

	public void insert(EmployeeDTO employee) {
		employeeRepository.insertEmployee(employee);
	}

	public void delete(int empId) {
		employeeRepository.removeEmployee(empId);
	}
	
	public List<EmployeeDTO> getAllCustomer() {
		return employeeRepository.fetchCustomer();
	}
	
	public EmployeeDTO getEmployee(int empId){
		// Write the code to fetch the employee details
		return employeeRepository.getEmployee(empId);
	}

}
